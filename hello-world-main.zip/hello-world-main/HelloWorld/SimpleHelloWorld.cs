namespace HelloWorld
{
    public static class SimpleHelloWorld
    {
        public static string ReturnHelloWorld()
        {
            return "Hello, world!";
        }
    }
}
