// function hello() {
//   console.log('Hello World')
// };
// hello();
//-----------------------------------------------------------


//  function hello(vardas) {
//    console.log('Hello ' + vardas)
//  };
// hello('Dainius');
// hello('Arnold');

//-----------------------------------------------------------

// const vardas = 'Dainius';
// let amzius = 10;
// function prabegoMetai() {
//   console.log(vardas, amzius++)
// };

// prabegoMetai();
// prabegoMetai();
// prabegoMetai();
// prabegoMetai();
// prabegoMetai();

//-----------------------------------------------------------

// function fizzAndBazz(string) {
//     if (string === 'fizz') { console.log('buzz') } else if (string === 'buzz') {
//         console.log('fizz')
//     } else { console.log('Please provide fizz or bazz') }}

//     fizzAndBazz('fizz');
//     fizzAndBazz('buzz');
//     fizzAndBazz('smizz');

//-----------------------------------------------------------

// function min(a , b, c) {
//   if ((a < b)&&(a < c)) {console.log(a)}
//   else if ((b < a)&&(b < c)) {console.log(b)}
//       else{console.log(c)}
// };

//   min (10,70,800);

//-----------------------------------------------------------

// function average(a,b,c) {
//   console.log((a+b+c)/3)
// }

// average (2,4,6);

//-----------------------------------------------------------

//     function inc(num){
//   num++;
//   return num;
// }
// let num = prompt('duok man skaiciu');
// const plusOne = inc(num);
// console.log(plusOne);

//-----------------------------------------------------------

// let A = ["Banana", "Orange", "Apple", "Mango"];
// let B = ["Ford", "Mazda", "Volvo", "Honda" , "Toyota"];

// function more(A , B) {
//   if (A.length > B.length) {console.log("A", A.length)}
//   else if (A.length < B.length)  {console.log("B",B.length)}
//   else {console.log("abu lygus")}
// }

// more(A, B);

//-----------------------------------------------------------

// function isSeven(x) {
// 	return (x="7")? true:false;
// }
// console.log(isSeven());

//-----------------------------------------------------------

// function isEqual(a, b) {
//  return (a===b);
// }

// console.log(isEqual(1, true));

// // isEqual(1, true) ➞ false
// // isEqual(1,  1) ➞ true

//-----------------------------------------------------------

// function ppp(prob, prize, pay ){
//   return ((prob*prize)>pay)
// }

// console.log(ppp(3,3,6));
//-----------------------------------------------------------
// let secs = function convert(min) {
//   return  (min*60)
// }
// console.log (secs(1),secs(2),secs(3));

//-----------------------------------------------------------

//  let metai = prompt('duok metus');
// function lyginiai(metai) {
//   if ((metai % 2) == 0 )  {console.log('Lyginiai metai')}
//   else {console.log('Nelyginiai metai')}
// }
// lyginiai(metai);

//-----------------------------------------------------------
// let vartoja = 5;
// function kastai(km , bKaina ) {
//   console.log((vartoja/100) * km * bKaina)
// };
// kastai (100, 2);
//-----------------------------------------------------------
