// 1

digits = () => { 
for (let index = 0; index <= 9; index++) {
    console.log(index)
}}
 // digits();

// 2

square = () => { 
for (let index = 0; index <= 9; index++) {
    console.log(index * index)
} }
// square();

// 3

doubleEven = () => { 
for (let index = 10; index <= 99; index++) {
    let rez = index % 2;
    if (rez === 0)
        console.log(index)

}}
 // doubleEven();

// 4

maxLimit = () => {
let x = 7;
for (let index = 0; index <= x; index++) {
    console.log(index)
}}
// maxLimit();


// 5

  range = () => { 
const min = 5;    
    let max = 10;
     for (let index = min; index <= max; index++);
   {
     console.log(index)
}
  }
// range();

// 6

nameRepeat = () => {
  const qty = prompt('kiek kartu spausdinti varda?');
  for (let index = 1; index <= qty; index++) {
  console.log('Dainius') }
}
// nameRepeat();

// 7

multiplyN = () => {
  const N = prompt('kokio skaiciaus daugyba?');
  for (let index = 1; index <=10; index++) {
    console.log(N +' * '+ index + ' = '+ N * index);
  }
}
// multiplyN();

// 8

// y = 7x2 + 5x – 3
// Kai x = -10, tai y = 647

equation = () => {
  for (let x = -10; x <=10; x++) {
    console.log('Kai x = ' + x + ' tai y = ' + ((7*x*x)+(5*x)-3));
  }
}
// equation();

// 9

// Įveskite intervalo pradžią: 5
// Įveskite intervalo pabaigą: 24
// GAUTA: Reikalingų marškinėlių skaičius: 4

luckyNumbers = () => {
  // let a = prompt('Įveskite intervalo pradžią:');
  // let b = prompt('Įveskite intervalo pabaigą:');
 let a = 5;
 let b = 24;

    // for (let index = prompt('Įveskite intervalo pradžią:'); index <= prompt('Įveskite intervalo pabaigą:'); index++)
  
    let quantity = 0;
  for ( index = a; index <= b; index++) {
    let result = ((index % 6)) == 0;
    if (result == true) { quantity++};
  }
  console.log('Reikalingų marškinėlių skaičius: ' + quantity);
}
 luckyNumbers();

// 10
average = () => {
    let height = [];
  let totalSum = 0;
  let treesQty = prompt('Kiek eglučių atvežta?');
  for (let index = 0 ; index < treesQty; index++) {
    height[index] = (prompt('Įveskite '+ (index+1) + ' eglutės aukštį:'))/1;
    totalSum += height[index];                        
  }
    
  console.log('Eglutės aukščio vidurkis: ' + (totalSum/treesQty) +' cm'); }
//  average();

// 11

// var str = 'cats'

// var output = str.substring(1, 3);

// console.log(output);

lucky = () => {
  let a = prompt('intervalo pradzia:')
  let b = prompt('intervalo pabaiga:')
  for (let index = a; index <= b; index++) {
    strings = `${index}`;
    let str1 = strings.substring(0, 2);
    let str2 = strings.substring(2, 4);
    if ((Math.pow(((str1/1)+(str2/1)),2)) == strings) {
      console.log(strings);
    }
    // console.log(strings, str1, str2);
  }
}
// lucky();