let keturi = 2 + 2;
console.log(keturi);

console.log('----------------------------');

let nulis = 2 - 2;
console.log(nulis);

console.log('----------------------------');

let astuoni = 2 * keturi;
console.log(astuoni);

console.log('----------------------------');

let du = astuoni / 4;
console.log(du);

console.log('----------------------------');
let sesi = 5;
sesi += 1;
console.log(sesi);
console.log('----------------------------');
var a = 10, b = '10';
var c = (10 > 5) ? 100 : 555; // value of c would be 10
console.log(c);
var d = a == b;
console.log(d);

const penki = 11;
console.log(penki % 2 ); 

let exp = 2**3;
console.log(exp);

let z = 8;
 console.log(z**=2);

console.log('----------------------------');

let arTrue = !(2<2)&&(3>1+1);
console.log(arTrue);

/*
alert(desimt);


let vardas = prompt("koks tavo vardas");
console.log(vardas);

*/

console.log('----------------------------');
let rezultatas = 11 !=="11";
console.log(rezultatas);