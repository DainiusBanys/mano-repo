// const NameOfTheSpcShtl = "Determination";
// const ShtlSpdMph = 17500;
// const Dstnc2MarsKm = 225000000;
// const Dstnc2TheMoonKm = 384400;
// const MlpKm = 0.621;

// console.log(NameOfTheSpcShtl);
// console.log(ShtlSpdMph);
// console.log(Dstnc2MarsKm);
// console.log(Dstnc2TheMoonKm);
// console.log(MlpKm);

let table = {NameOfTheSpcShtl: "Determination" , ShtlSpdMph: 17500 , Dstnc2MarsKm: 225000000 , Dstnc2TheMoonKm: 384400,  MlpKm: 0.621  };

console.log(table);