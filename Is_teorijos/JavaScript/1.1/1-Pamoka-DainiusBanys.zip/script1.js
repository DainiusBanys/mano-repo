const vardas = "Dainius";
const pavarde = "Banys";
let amzius = 46;
console.log(vardas , pavarde , amzius);
amzius++;
console.log(vardas , pavarde , amzius);