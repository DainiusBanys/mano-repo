var a = 10;
console.log(a);
var a = 5;
console.log(a);

console.log("---------------------------")

let b = 20;
console.log(b);
// negalima du kartus deklaruoti to pacio kintamojo, tik priskirti nauja reiksme 
// let b = 3;
// console.log(b);

console.log("---------------------------")

const c = 4;
console.log(c);
//  const - negalima keisti reiksmes, tai konstanta, nekintamas pastovus dydis
// const c = 8;  
// console.log(c);

