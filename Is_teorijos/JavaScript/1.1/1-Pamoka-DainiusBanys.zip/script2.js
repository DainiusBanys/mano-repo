const price = 10;
const tax = 0.21;
let total = (price*tax)+price;
console.log(price , tax , total);